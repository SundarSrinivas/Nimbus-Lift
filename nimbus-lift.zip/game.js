//alert("game.js loaded");
// ─── CANVAS SETUP ────────────────────────────────────────
const cv = document.getElementById('c');
const ctx = cv.getContext('2d');
function resize() {
  cv.width = window.innerWidth;
  cv.height = window.innerHeight;
}
resize();
window.addEventListener('resize', resize);
function W() { return cv.width; }
function H() { return cv.height; }

// ─── AUDIO ──────────────────────────────────────────────
let AC = null;
function ac() { if (!AC) AC = new (window.AudioContext || window.webkitAudioContext)(); return AC; }
let muted = false;
document.getElementById('mute').addEventListener('click', e => {
  e.stopPropagation(); muted = !muted;
  document.getElementById('mute').textContent = muted ? '🔇' : '🔊';
  if (muted) stopAmb(); else if (playing) startAmb();
});

function tone(freq, type, vol, dur, freqEnd) {
  if (muted) return;
  try {
    const a = ac(), o = a.createOscillator(), g = a.createGain();
    o.type = type; o.frequency.setValueAtTime(freq, a.currentTime);
    if (freqEnd) o.frequency.exponentialRampToValueAtTime(freqEnd, a.currentTime + dur);
    g.gain.setValueAtTime(vol, a.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001, a.currentTime + dur);
    o.connect(g); g.connect(a.destination); o.start(); o.stop(a.currentTime + dur + 0.01);
  } catch(e) {}
}
function noise(vol, dur, bpFreq) {
  if (muted) return;
  try {
    const a = ac(), sr = a.sampleRate, buf = a.createBuffer(1, sr*dur, sr), d = buf.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = (Math.random()*2-1) * (1 - i/d.length);
    const src = a.createBufferSource(); src.buffer = buf;
    const f = a.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = bpFreq; f.Q.value = 0.6;
    const g = a.createGain(); g.gain.setValueAtTime(vol, a.currentTime); g.gain.exponentialRampToValueAtTime(0.001, a.currentTime + dur);
    src.connect(f); f.connect(g); g.connect(a.destination); src.start(); src.stop(a.currentTime + dur + 0.01);
  } catch(e) {}
}
function sfxWhoosh() { tone(260, 'sine', 0.09, 0.13, 540); }
function sfxSplash() { [0,.03,.06,.09].forEach((d,i)=>{setTimeout(()=>tone(500+i*100,'sine',0.1,0.14,130+i*25),d*1000);}); }
function sfxPigeon() { tone(400,'triangle',0.13,0.1,300); setTimeout(()=>tone(350,'triangle',0.09,0.12,260),80); }
function sfxWindSnd() { noise(0.14, 0.38, 360); }
function sfxThunder() {
  noise(0.5, 0.55, 600);
  setTimeout(() => tone(110, 'sawtooth', 0.28, 0.4, 28), 30);
}
function sfxThud() { tone(88,'sine',0.24,0.14,36); }
function sfxDeath() { [580,460,360,260,160].forEach((f,i)=>setTimeout(()=>tone(f,'sine',0.15,0.13,f*0.48),i*70)); }
function sfxChime() { [523,659,784,1047].forEach((f,i)=>setTimeout(()=>tone(f,'triangle',0.14,0.24),i*100)); }
let ambNodes = [];
function startAmb() {
  if (muted || ambNodes.length) return;
  try {
    const a = ac();
    const o = a.createOscillator(), gh = a.createGain();
    o.type = 'sine'; o.frequency.value = 50; gh.gain.value = 0.03;
    o.connect(gh); gh.connect(a.destination); o.start();
    const bs = a.sampleRate * 2, buf = a.createBuffer(1, bs, a.sampleRate), d = buf.getChannelData(0);
    for (let i = 0; i < bs; i++) d[i] = Math.random()*2-1;
    const ns = a.createBufferSource(); ns.buffer = buf; ns.loop = true;
    const fl = a.createBiquadFilter(); fl.type = 'bandpass'; fl.frequency.value = 260; fl.Q.value = 0.35;
    const gw = a.createGain(); gw.gain.value = 0.025;
    const lfo = a.createOscillator(), lg = a.createGain();
    lfo.frequency.value = 0.12; lg.gain.value = 0.014;
    lfo.connect(lg); lg.connect(gw.gain); lfo.start();
    ns.connect(fl); fl.connect(gw); gw.connect(a.destination); ns.start();
    ambNodes = [o, ns, lfo];
  } catch(e) {}
}
function stopAmb() { ambNodes.forEach(n=>{try{n.stop();}catch(e){}}); ambNodes=[]; }

// ─── SKY PHASES ──────────────────────────────────────────
const SKIES = [
  { stops: [[0,'#3a1260'],[0.32,'#c45e8a'],[0.66,'#ff8c60'],[1,'#ffd580']], sun: {x:.72,y:.17,c:'rgba(255,200,80,0.92)',r:17}, moon: null, starA: 0 },
  { stops: [[0,'#120830'],[0.38,'#5a1e60'],[0.68,'#b03850'],[1,'#e06840']], sun: null, moon: null, starA: 0.22 },
  { stops: [[0,'#020510'],[0.5,'#050d22'],[1,'#081228']], sun: null, moon: {x:.78,y:.13,r:19}, starA: 1 },
  { stops: [[0,'#060820'],[0.28,'#1a2e60'],[0.6,'#d05830'],[1,'#f0a040']], sun: null, moon: null, starA: 0.15 },
  { stops: [[0,'#1460a8'],[0.4,'#3a90cc'],[0.72,'#70bce0'],[1,'#b8e4f8']], sun: {x:.74,y:.14,c:'rgba(255,240,140,0.95)',r:21}, moon: null, starA: 0 },
];
let skyIdx = 0, nextSkyPts = 500 + Math.floor(Math.random()*151);

// ─── WORLDS ──────────────────────────────────────────────
const WORLD_NAMES = ['City', 'Forest', 'Mountains', 'Desert'];
let worldIdx = 0, nextWorldPts = 1000;

// ─── GAME STATE ──────────────────────────────────────────
let playing = false, fr = 0, spd = 0;
let score = 0, hi = 0;
let comboCount = 0, comboTimer = 0;
let sx = 0, sy = 0;
let skyFlash = 0;
let thudTimer = 0, wasNewBest = false, deathReason = '';
let tutDone = false, tutTimer = 0;
let held = false, lastTap = 0, tapCount = 0, holdStarted = false, ceilingLocked = false;

// Cloud
let C = {};
// Entity pools
let obs = [], farObs = [], drops = [], winds = [], bolts = [], birds = [], parts = [];

// Difficulty wave
const WAVE = [1,2,3,2,1,3,2,2,3,1];
let waveIdx = 0, waveTimer = 0;
function diff() { return WAVE[waveIdx % WAVE.length]; }

// ─── INIT ────────────────────────────────────────────────
function initGame() {
  C = { x: W()*0.18, y: H()*0.45, vy: 0, w: 0, eye: 'happy', jig: 0, droop: 0, burstT: 0, dead: false };
  obs = []; farObs = []; drops = []; winds = []; bolts = []; birds = []; parts = [];
  score = 0; fr = 0; spd = 2.5;
  waveIdx = 0; waveTimer = 0; comboCount = 0; comboTimer = 0;
  tutDone = false; tutTimer = 0; held = false; holdStarted = false;
  thudTimer = 0; wasNewBest = false; deathReason = '';
  sx = 0; sy = 0; skyFlash = 0; ceilingLocked = false;
  skyIdx = 0; nextSkyPts = 500 + Math.floor(Math.random()*151);
  worldIdx = 0; nextWorldPts = 1000;
  buildObs(W()*0.55, W()*3.5, false);
  buildObs(0, W()*3, true);
}

// ─── OBSTACLE BUILDERS ───────────────────────────────────
function buildObs(sx2, ex, far) {
  let x = sx2;
  const pool = far ? farObs : obs;
  const wid = WORLD_NAMES[worldIdx];
  while (x < ex) {
    const o = makeObs(x, far, wid);
    pool.push(o);
    x += o.w + (far ? 8 + Math.random()*20 : 22 + Math.random()*46);
  }
}

function makeObs(x, far, wid) {
  const bh = far ? (50 + Math.random()*110) : (72 + Math.random()*235);
  const bw = far ? (26 + Math.random()*42) : (46 + Math.random()*44);
  const o = { x, y: H()-bh, w: bw, h: bh, far, wid, wins: [], ant: false, wt: false, ex: {} };

  if (wid === 'City') {
    o.col = far ? '#1a0f35' : (['#3d2060','#2d1b4e','#4a2878'][Math.floor(Math.random()*3)]);
    o.ant = !far && Math.random() > 0.52;
    o.wt  = !far && Math.random() > 0.68;
    if (!far) {
      for (let wy = o.y+14; wy < H()-20; wy += 22)
        for (let wx = x+8; wx < x+bw-10; wx += 16)
          o.wins.push({ lx: wx, ly: wy, on: Math.random() > 0.33 });
    }
  } else if (wid === 'Forest') {
    o.col = far
      ? `hsl(${120+Math.random()*20},${35+Math.random()*15}%,${14+Math.random()*8}%)`
      : `hsl(${118+Math.random()*25},${50+Math.random()*18}%,${18+Math.random()*10}%)`;
    o.ex.trunk = bw * 0.16;
    o.ex.layers = buildTreeLayers(x, bh, bw);
  } else if (wid === 'Mountains') {
    o.col = far
      ? `hsl(240,${8+Math.random()*8}%,${18+Math.random()*8}%)`
      : `hsl(240,${10+Math.random()*10}%,${22+Math.random()*12}%)`;
    o.ex.pts = buildMountainPts(x, bh, bw);
    o.ex.snow = bh > 130;
    o.ex.snowPts = o.ex.snow ? buildSnowPts(o.ex.pts, bh, bw) : [];
  } else if (wid === 'Desert') {
    o.col = far
      ? `hsl(38,${55+Math.random()*15}%,${32+Math.random()*10}%)`
      : `hsl(38,${65+Math.random()*18}%,${46+Math.random()*14}%)`;
    o.ex.dunePts = buildDunePts(x, bh, bw);
    o.ex.cactus = !far && Math.random() > 0.45;
    o.ex.cactusX = x + bw * (0.35 + Math.random()*0.3);
    o.ex.cactusH = 28 + Math.random()*24;
  }
  return o;
}

function buildTreeLayers(x, bh, bw) {
  const cx = x + bw/2;
  const layers = [];
  const nLayers = bh > 140 ? 4 : bh > 90 ? 3 : 2;
  for (let i = 0; i < nLayers; i++) {
    const t = i / (nLayers - 1 || 1);
    const tipY = H() - bh + bh * t * 0.52;
    const baseY = H() - bh * (0.08 + (1-t)*0.28) + bh*(t*0.42);
    const halfW = bw * (0.55 + t*0.22);
    layers.push({ tipX: cx + (-4+Math.random()*8), tipY, baseY, halfW });
  }
  return layers;
}

function buildMountainPts(x, bh, bw) {
  const pts = [{ x, y: H() }];
  const steps = 5 + Math.floor(Math.random()*4);
  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    const env = 1 - Math.pow((t - 0.5)*2, 2);
    const jagg = (i%2===0 ? 0 : 0.25 + Math.random()*0.2);
    pts.push({ x: x + bw*t, y: H() - bh*env*(0.7 + jagg) });
  }
  pts.push({ x: x+bw, y: H() });
  return pts;
}

function buildSnowPts(mpts, bh, bw) {
  const threshold = H() - bh * 0.72;
  return mpts.filter(p => p.y <= threshold + 10);
}

function buildDunePts(x, bh, bw) {
  const pts = [{ x, y: H() }];
  const steps = 14;
  for (let i = 0; i <= steps; i++) {
    const t = i/steps;
    const ht = Math.sin(t * Math.PI) * bh + Math.sin(t*Math.PI*2)*bh*0.08;
    pts.push({ x: x+bw*t, y: H()-ht });
  }
  pts.push({ x: x+bw, y: H() });
  return pts;
}

function extObs() {
  const l = obs.length ? obs[obs.length-1] : {x:W(),w:0};
  if (l.x + l.w < W()*2) buildObs(l.x+l.w+22, l.x+l.w+400, false);
  const lf = farObs.length ? farObs[farObs.length-1] : {x:W(),w:0};
  if (lf.x + lf.w < W()*2) buildObs(lf.x+lf.w+8, lf.x+lf.w+280, true);
}

// ─── UPDATE ──────────────────────────────────────────────
function update() {
  fr++; score = Math.floor(fr/3);
  if (score > hi) { hi = score; }

  // Sky phase
  if (score >= nextSkyPts) {
    skyIdx = (skyIdx+1) % SKIES.length;
    nextSkyPts = score + 500 + Math.floor(Math.random()*151);
  }

  // World swap
  if (score >= nextWorldPts) {
    worldIdx = (worldIdx+1) % WORLD_NAMES.length;
    nextWorldPts = score + 1000;
    obs = []; farObs = [];
    buildObs(W()*0.3, W()*3.2, false);
    buildObs(0, W()*2.6, true);
  }

  spd = 3.2 + fr * 0.0008;
  sx *= 0.65; sy *= 0.65;
  skyFlash = Math.max(0, skyFlash - 0.055);
  if (!tutDone) { tutTimer++; if (tutTimer > 240) tutDone = true; }

  // Cloud physics
  if (held && !ceilingLocked) { C.vy -= 0.235; C.jig = Math.min(C.jig+0.6, 3); }
  else { C.vy += 0.105 + C.w*0.12; C.jig = Math.max(C.jig-0.22, 0); }
  C.vy = Math.max(-5.8, Math.min(C.vy, 6.2));
  if (!C.dead) { C.y += C.vy; C.x = Math.max(W()*0.08, Math.min(W()*0.35, C.x)); }
  C.droop = C.w * 5 * Math.sin(fr*0.055);
  C.eye = C.w > 0.68 ? 'scared' : C.w > 0.42 ? 'worried' : 'happy';

  if (C.y < 18) {
    // Only snap+dampen if not locked — when locked let it fall freely
    if (!ceilingLocked) {
      C.y = 18; C.vy = Math.abs(C.vy)*0.3;
    }
    // Ceiling penalty: holding at top waterloads the cloud fast
    if (held && !C.dead && !ceilingLocked) {
      C.w = Math.min(1, C.w + 0.012);
      if (fr % 4 === 0) spawnPart(C.x+(-24+Math.random()*48), C.y+20, 'rgba(89,180,240,0.88)', (-3+Math.random()*6), (2+Math.random()*4));
      if (C.w >= 0.95 && !C.dead) { ceilingLocked = true; C.vy = 4.5; }
    }
  }
  if (C.y > H()-60 && !C.dead) die('fell');

  // Combo
  if (C.w < 0.32 && !C.dead) { comboTimer++; if (comboTimer > 65) { comboCount = Math.min(comboCount+1,8); comboTimer=0; } }
  else { comboCount = Math.max(0, comboCount-1); comboTimer=0; }

  if (!C.dead) C.w = Math.max(0, C.w - 0.0006);
  if (C.w >= 1 && !C.dead) die('overload');

  // Critical weight heartbeat
  if (C.w > 0.72 && !C.dead) {
    thudTimer++;
    if (thudTimer >= Math.floor(34-C.w*24)) { thudTimer=0; sfxThud(); }
  } else thudTimer = 0;

  // Rain drops FROM cloud
  if (!C.dead && fr % Math.max(5, Math.round(14 - spd*0.9)) === 0) {
    const n = 1 + (spd > 5 && Math.random()>0.5 ? 1 : 0);
    for (let i=0;i<n;i++) {
      const ox = -22+Math.random()*44;
      drops.push({ x:C.x+ox, y:C.y+22, vx:ox*0.035, vy:2.3+Math.random()*2, r:2.8+Math.random()*2.5, a:1 });
    }
  }
  for (let i=drops.length-1;i>=0;i--) {
    const r=drops[i]; r.x+=r.vx; r.y+=r.vy; r.vy+=0.07;
    if (r.y > H()+10) r.a=0;
  }
  drops = drops.filter(r=>r.a>0);

  // Obstacles scroll
  obs.forEach(b => {
    b.x -= spd;
    if (b.wins) b.wins.forEach(w => w.lx -= spd);
    shiftPts(b.ex.pts, -spd);
    shiftPts(b.ex.snowPts, -spd);
    shiftPts(b.ex.dunePts, -spd);
    if (b.ex.layers) b.ex.layers.forEach(l => { l.tipX-=spd; });
    if (b.ex.cactusX !== undefined) b.ex.cactusX -= spd;
  });
  farObs.forEach(b => {
    const fs = spd*0.44;
    b.x -= fs;
    shiftPts(b.ex.pts, -fs);
    shiftPts(b.ex.dunePts, -fs);
    if (b.ex.layers) b.ex.layers.forEach(l => { l.tipX-=fs; });
  });
  obs    = obs.filter(b => b.x + b.w > -100);
  farObs = farObs.filter(b => b.x + b.w > -100);
  extObs();

  // Collision
  obs.forEach(b => {
    if (b.x > W()+10 || b.x+b.w < -10) return;
    if (circRect(C.x, C.y, 19, b.x, b.y, b.w, b.h) && !C.dead) die('building');
  });

  // Winds
  if (fr % Math.max(55, Math.round(115 - spd*8)) === 0 && spd > 3.5) spawnWind();
  for (let i=winds.length-1;i>=0;i--) {
    const w=winds[i]; w.x-=spd; w.life--;
    if (C.x>w.x && C.x<w.x+w.w && C.y>w.y && C.y<w.y+w.h) {
      C.vy += w.str*(-0.055); C.x += w.str*0.4;
    }
    if (w.life<=0 || w.x+w.w<-10) winds.splice(i,1);
  }

  // LIGHTNING
  if (fr % 125 === 0 && C.w > 0.38) spawnBolt();
  for (let i=bolts.length-1;i>=0;i--) {
    const b=bolts[i]; b.life--;
    if (b.life > b.max*0.5) {
      const tip = b.pts[b.pts.length-1];
      tip.x += (C.x - tip.x)*0.04;
    }
    b.pts.forEach(p => p.x -= spd*0.42);

    if (b.life === Math.floor(b.max*0.5) && !b.hit) {
      skyFlash = 1;
      sfxThunder();
      const tip = b.pts[b.pts.length-1];
      const dx = tip.x - C.x, dy = tip.y - C.y;
      if (dx*dx + dy*dy < 60*60) {
        sx=9; sy=7;
        C.w = Math.min(1, C.w+0.3);
        b.hit = true;
        for (let j=0;j<16;j++) spawnPart(C.x+(-20+Math.random()*40), C.y+(-15+Math.random()*30), '#ffe566', (-5+Math.random()*10), (-5+Math.random()*7));
        for (let j=0;j<8;j++) spawnPart(C.x+(-10+Math.random()*20), C.y+(-8+Math.random()*16), '#fff', (-3+Math.random()*6), (-3+Math.random()*5));
        if (C.w >= 0.88 && !C.dead) die('lightning');
      }
    }
    if (b.life <= 0) bolts.splice(i,1);
  }

  // Birds (pigeons)
  if (fr % 200 === 0) spawnBird();
  for (let i=birds.length-1;i>=0;i--) {
    const p=birds[i]; p.x+=p.vx; p.y+=Math.sin(fr*0.038+i)*0.4; p.flap+=0.22; p.wing=Math.sin(p.flap)*0.8;
    const dx=p.x-C.x, dy=p.y-C.y;
    if (dx*dx+dy*dy < 28*28 && !C.dead) {
      C.w = Math.max(0, C.w-0.12); C.vy -= 1.3;
      sx=4; sy=-3;
      sfxPigeon();
      for (let j=0;j<20;j++) spawnPart(C.x+(-18+Math.random()*36), C.y+(-12+Math.random()*24),
        ['rgba(255,255,255,0.9)','rgba(89,180,240,0.85)','rgba(200,220,255,0.8)'][j%3],
        (-4+Math.random()*8), (-4+Math.random()*6));
      for (let j=0;j<8;j++) spawnPart(p.x+(-8+Math.random()*16), p.y+(-6+Math.random()*12),
        ['#b090e0','#c8a8f0'][j%2], (-3+Math.random()*6), (-3+Math.random()*4));
      birds.splice(i,1); continue;
    }
    if (p.x < -70 || p.x > W()+70) birds.splice(i,1);
  }

  // Danger glow
  if (C.w > 0.7) {
    const a=(C.w-0.7)/0.3, pulse=0.3+0.3*Math.sin(fr*0.18);
    document.getElementById('danger').style.boxShadow = `inset 0 0 ${10+a*18}px rgba(220,55,55,${(a*pulse).toFixed(2)})`;
  } else document.getElementById('danger').style.boxShadow='none';

  // Particles
  parts.forEach(p=>{ p.x+=p.vx; p.y+=p.vy; p.vy+=0.055; p.vx*=0.96; p.life--; });
  parts = parts.filter(p=>p.life>0);
}

function shiftPts(arr, dx) { if (arr) arr.forEach(p=>p.x+=dx); }
function circRect(cx,cy,cr,rx,ry,rw,rh) {
  const nx=Math.max(rx,Math.min(cx,rx+rw)), ny=Math.max(ry,Math.min(cy,ry+rh));
  return (cx-nx)**2+(cy-ny)**2 < cr*cr;
}
function die(r) {
  if (C.dead) return; C.dead=true; deathReason=r;
  stopAmb();
  playing=false;
}

// ─── SPAWNERS ────────────────────────────────────────────
function spawnWind() {
  const y=H()*0.08+Math.random()*H()*0.65, h=55+Math.random()*70;
  const str=(0.5+Math.random()*1.5)*(Math.random()>0.5?1:-1);
  winds.push({x:W()+30,y:y-h/2,w:100,h,str,life:145,max:145}); sfxWindSnd();
}
function spawnBolt() {
  if (C.w < 0.38) return;
  const startX = C.x + (-60+Math.random()*120);
  const pts = [{x:startX, y:0}];
  let cy = 0;
  while (cy < H()-50) {
    cy += 13 + Math.random()*16;
    const px = pts[pts.length-1].x + (-20+Math.random()*40);
    pts.push({x:px, y:cy});
  }
  pts.push({x: C.x+(-12+Math.random()*24), y: C.y});
  bolts.push({pts, life:45, max:45, hit:false});
}
function spawnBird() {
  const left=Math.random()>0.5, y=H()*0.1+Math.random()*H()*0.6;
  birds.push({x:left?-35:W()+35, y, vx:left?2.5+Math.random():-(2.5+Math.random()), flap:0, wing:0});
}
function spawnPart(x,y,col,vx,vy) {
  parts.push({x,y,vx,vy,life:42,max:42,col,r:2.5+Math.random()*3.5});
}

// ─── DRAW ────────────────────────────────────────────────
function draw() {
  ctx.save();
  if (Math.abs(sx)>0.3 || Math.abs(sy)>0.3) ctx.translate(sx,sy);
  ctx.clearRect(-20,-20,W()+40,H()+40);

  dSky(); dCelestial();
  dFarObs(); dWinds(); dNearObs();
  dDrops(); dBolts(); dBirds();
  if (!C.dead || C.burstT < 10) dCloud();
  dParts();
  dGround();

  // Sky flash (lightning)
  if (skyFlash > 0) {
    ctx.fillStyle = `rgba(255,255,240,${skyFlash*0.48})`;
    ctx.fillRect(0,0,W(),H());
  }

  if (playing) dHUD();
  ctx.restore();
}

function dSky() {
  const sky = SKIES[skyIdx];
  const g = ctx.createLinearGradient(0,0,0,H());
  sky.stops.forEach(s => g.addColorStop(s[0],s[1]));
  ctx.fillStyle=g; ctx.fillRect(0,0,W(),H());
  if (sky.starA > 0) {
    for (let i=0;i<40;i++) {
      const bri = sky.starA * (0.35 + 0.55*(Math.sin(fr*0.045+i*2.3)*0.5+0.5));
      ctx.fillStyle=`rgba(255,255,255,${bri.toFixed(2)})`;
      ctx.beginPath(); ctx.arc((i*137+11)%W(), (i*97+5)%(H()*0.55), 0.7+i%3*0.4, 0, Math.PI*2); ctx.fill();
    }
  }
}

function dCelestial() {
  const sky = SKIES[skyIdx];
  if (sky.moon) {
    const {x,y,r} = sky.moon;
    const mx=W()*x, my=H()*y;
    ctx.fillStyle='rgba(200,220,180,0.12)'; ctx.beginPath(); ctx.arc(mx,my,r*2.2,0,Math.PI*2); ctx.fill();
    ctx.fillStyle='rgba(225,235,210,0.92)'; ctx.beginPath(); ctx.arc(mx,my,r,0,Math.PI*2); ctx.fill();
    ctx.fillStyle=SKIES[2].stops[0][1]; ctx.beginPath(); ctx.arc(mx+r*0.35,my-r*0.2,r*0.78,0,Math.PI*2); ctx.fill();
  }
  if (sky.sun) {
    const {x,y,c,r} = sky.sun;
    const sx2=W()*x, sy2=H()*y;
    ctx.fillStyle=c.replace('0.92','0.13').replace('0.95','0.13');
    ctx.beginPath(); ctx.arc(sx2,sy2,r*2.1,0,Math.PI*2); ctx.fill();
    ctx.fillStyle=c; ctx.beginPath(); ctx.arc(sx2,sy2,r,0,Math.PI*2); ctx.fill();
  }
}

function dFarObs() {
  farObs.forEach(b => {
    if (b.x > W()+10 || b.x+b.w < -10) return;
    ctx.globalAlpha = 0.4;
    drawObsShape(b);
    ctx.globalAlpha = 1;
  });
}
function dNearObs() {
  obs.forEach(b => {
    if (b.x > W()+10 || b.x+b.w < -10) return;
    drawObsShape(b);
  });
}

function drawObsShape(b) {
  const wid = b.wid || WORLD_NAMES[worldIdx];
  if (wid==='City') {
    ctx.fillStyle=b.col; ctx.fillRect(b.x,b.y,b.w,b.h+2);
    if (!b.far) {
      ctx.fillStyle='rgba(107,63,160,0.55)'; ctx.fillRect(b.x,b.y,b.w,3);
      b.wins.forEach(w => {
        ctx.fillStyle=w.on?'rgba(255,213,128,0.88)':'rgba(15,8,35,0.65)';
        ctx.fillRect(w.lx,w.ly,7,9);
      });
      if (b.ant) {
        ctx.strokeStyle='#8b5ec0'; ctx.lineWidth=1.5;
        ctx.beginPath(); ctx.moveTo(b.x+b.w/2,b.y); ctx.lineTo(b.x+b.w/2,b.y-28); ctx.stroke();
        ctx.fillStyle='#e24b4a'; ctx.beginPath(); ctx.arc(b.x+b.w/2,b.y-30,3,0,Math.PI*2); ctx.fill();
      }
      if (b.wt) {
        ctx.fillStyle='#2d1b4e'; ctx.fillRect(b.x+b.w/2-7,b.y-27,14,20);
        ctx.strokeStyle='#6B3FA0'; ctx.lineWidth=1; ctx.strokeRect(b.x+b.w/2-7,b.y-27,14,20);
        ctx.fillStyle='#2d1b4e'; ctx.beginPath();
        ctx.ellipse(b.x+b.w/2,b.y-27,10,5,0,Math.PI,0); ctx.fill();
      }
    }
  } else if (wid==='Forest') {
    const tr = b.ex.trunk||b.w*0.16;
    ctx.fillStyle = b.far ? '#2a180a' : '#4a2a10';
    ctx.fillRect(b.x+b.w/2-tr/2, H()-b.h*0.2, tr, b.h*0.2+2);
    if (b.ex.layers) {
      b.ex.layers.forEach((l, i) => {
        const shade = b.far ? 0 : (i/(b.ex.layers.length-1||1))*0.18;
        ctx.fillStyle = shiftLightness(b.col, shade);
        ctx.beginPath();
        ctx.moveTo(l.tipX, l.tipY);
        ctx.lineTo(l.tipX - l.halfW, l.baseY);
        ctx.lineTo(l.tipX + l.halfW, l.baseY);
        ctx.closePath(); ctx.fill();
        if (!b.far && i===0 && b.h > 100) {
          ctx.fillStyle='rgba(230,240,255,0.55)';
          ctx.beginPath(); ctx.arc(l.tipX, l.tipY+4, l.halfW*0.18, 0, Math.PI*2); ctx.fill();
        }
      });
    }
  } else if (wid==='Mountains') {
    if (b.ex.pts && b.ex.pts.length) {
      ctx.fillStyle=b.col;
      ctx.beginPath(); b.ex.pts.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));
      ctx.closePath(); ctx.fill();
      if (!b.far) {
        ctx.strokeStyle='rgba(180,185,220,0.18)'; ctx.lineWidth=1.5;
        ctx.beginPath(); b.ex.pts.slice(1,-1).forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y)); ctx.stroke();
      }
      if (b.ex.snow && !b.far && b.ex.snowPts.length > 1) {
        ctx.fillStyle='rgba(228,236,255,0.88)';
        ctx.beginPath(); b.ex.snowPts.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));
        const leftPt = b.ex.snowPts[0], rightPt = b.ex.snowPts[b.ex.snowPts.length-1];
        ctx.lineTo(rightPt.x, rightPt.y+22); ctx.lineTo(leftPt.x, leftPt.y+22);
        ctx.closePath(); ctx.fill();
      }
    }
  } else if (wid==='Desert') {
    if (b.ex.dunePts && b.ex.dunePts.length) {
      ctx.fillStyle=b.col;
      ctx.beginPath(); b.ex.dunePts.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));
      ctx.closePath(); ctx.fill();
      if (!b.far) {
        ctx.strokeStyle=`rgba(255,240,160,0.22)`; ctx.lineWidth=1.5;
        ctx.beginPath(); b.ex.dunePts.slice(1,-1).forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y)); ctx.stroke();
      }
    }
    if (b.ex.cactus && !b.far) {
      const cx=b.ex.cactusX, ch=b.ex.cactusH;
      const cy=b.y-8;
      ctx.fillStyle='#2a7a2a';
      ctx.beginPath(); ctx.roundRect(cx-3.5,cy-ch,7,ch+6,3); ctx.fill();
      ctx.beginPath(); ctx.roundRect(cx-14,cy-ch*0.55,12,5,2); ctx.fill();
      ctx.beginPath(); ctx.roundRect(cx-14,cy-ch*0.55-10,5,11,2); ctx.fill();
      ctx.beginPath(); ctx.roundRect(cx+2,cy-ch*0.42,12,5,2); ctx.fill();
      ctx.beginPath(); ctx.roundRect(cx+9,cy-ch*0.42-9,5,10,2); ctx.fill();
    }
  }
}

function shiftLightness(hslStr, amount) {
  const m = hslStr.match(/hsl\((\d+),(\d+)%,(\d+)%\)/);
  if (!m) return hslStr;
  const l = Math.min(100, Math.round(parseInt(m[3]) * (1+amount)));
  return `hsl(${m[1]},${m[2]}%,${l}%)`;
}

function dWinds() {
  winds.forEach(w => {
    const a = w.life/w.max;
    ctx.globalAlpha = a*0.32;
    const g = ctx.createLinearGradient(w.x,0,w.x+w.w,0);
    g.addColorStop(0,'transparent'); g.addColorStop(0.5,'rgba(255,255,255,0.2)'); g.addColorStop(1,'transparent');
    ctx.fillStyle=g; ctx.fillRect(w.x,w.y,w.w,w.h);
    ctx.globalAlpha = a*0.5;
    ctx.strokeStyle='rgba(255,255,255,0.35)'; ctx.lineWidth=1.2;
    for (let j=0;j<4;j++) {
      const ly = w.y+w.h*(0.12+j*0.24), off=Math.sin(fr*0.07+j)*2.5;
      ctx.beginPath();
      ctx.moveTo(w.x+4, ly+off);
      ctx.bezierCurveTo(w.x+w.w*0.28,ly+off-3, w.x+w.w*0.72,ly+off+3, w.x+w.w-4,ly+off);
      ctx.stroke();
    }
    ctx.globalAlpha=1;
  });
}

function dDrops() {
  drops.forEach(r => {
    ctx.globalAlpha=0.82;
    ctx.fillStyle='rgba(89,180,240,0.85)';
    ctx.beginPath(); ctx.ellipse(r.x,r.y,r.r*0.4,r.r,Math.atan2(r.vy,r.vx)+Math.PI/2,0,Math.PI*2); ctx.fill();
  }); ctx.globalAlpha=1;
}

function dBolts() {
  bolts.forEach(b => {
    const phase = b.life/b.max;
    const isWarn = phase > 0.5;
    const tip = b.pts[b.pts.length-1];
    if (isWarn) {
      const pa = (0.4+0.55*Math.sin(fr*0.35)) * (1-phase)*3;
      ctx.globalAlpha=Math.min(pa*0.5,0.4);
      const grad = ctx.createRadialGradient(tip.x,tip.y,0,tip.x,tip.y,32);
      grad.addColorStop(0,'rgba(255,240,80,0.9)'); grad.addColorStop(1,'transparent');
      ctx.fillStyle=grad; ctx.beginPath(); ctx.arc(tip.x,tip.y,32,0,Math.PI*2); ctx.fill();
      ctx.globalAlpha=Math.min(pa*0.9,0.85);
      ctx.fillStyle='rgba(255,248,100,0.95)'; ctx.beginPath(); ctx.arc(tip.x,tip.y,5+Math.sin(fr*0.4)*2,0,Math.PI*2); ctx.fill();
      ctx.globalAlpha=1;
    } else {
      const ba = Math.min(1,(0.5-phase)/0.5*2.5);
      ctx.globalAlpha=ba*0.3;
      ctx.strokeStyle='rgba(255,248,80,0.6)'; ctx.lineWidth=16;
      drawBoltPath(b.pts);
      ctx.globalAlpha=ba*0.55;
      ctx.strokeStyle='rgba(255,248,140,0.8)'; ctx.lineWidth=7;
      drawBoltPath(b.pts);
      ctx.globalAlpha=ba;
      ctx.strokeStyle='#ffffff'; ctx.lineWidth=2.5;
      drawBoltPath(b.pts);
      ctx.strokeStyle='#fffbaa'; ctx.lineWidth=1.2;
      drawBoltPath(b.pts);
      if (b.pts.length > 4) {
        const mi = Math.floor(b.pts.length*0.4), mp=b.pts[mi];
        ctx.globalAlpha=ba*0.6;
        ctx.strokeStyle='rgba(255,248,140,0.7)'; ctx.lineWidth=2;
        ctx.beginPath(); ctx.moveTo(mp.x,mp.y);
        ctx.lineTo(mp.x+(-25+Math.random()*50), mp.y+35+Math.random()*30); ctx.stroke();
      }
      ctx.globalAlpha=1;
    }
  });
}

function drawBoltPath(pts) {
  ctx.beginPath(); pts.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y)); ctx.stroke();
}

function dBirds() {
  birds.forEach((p,i) => {
    ctx.save(); ctx.translate(p.x,p.y); if(p.vx<0) ctx.scale(-1,1);
    ctx.fillStyle='#9b7cc7';
    ctx.beginPath(); ctx.ellipse(0,0,11,6,0,0,Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.arc(11,-2.5,4.5,0,Math.PI*2); ctx.fill();
    ctx.fillStyle='#e8b860';
    ctx.beginPath(); ctx.moveTo(15,-2); ctx.lineTo(20,-3); ctx.lineTo(15,0); ctx.closePath(); ctx.fill();
    ctx.fillStyle='#fff'; ctx.beginPath(); ctx.arc(12,-3.5,1.5,0,Math.PI*2); ctx.fill();
    ctx.fillStyle='#222'; ctx.beginPath(); ctx.arc(12.5,-3.5,0.8,0,Math.PI*2); ctx.fill();
    ctx.fillStyle='#b090e0';
    ctx.beginPath(); ctx.ellipse(-2, p.wing*7-3, 9, 4, p.wing*0.4, 0, Math.PI*2); ctx.fill();
    ctx.fillStyle='#8b6bb1';
    ctx.beginPath(); ctx.moveTo(-10,0); ctx.lineTo(-18,3); ctx.lineTo(-18,-3); ctx.closePath(); ctx.fill();
    ctx.restore();
  });
}

function cloudColor(w) {
  const r=Math.round(245-(245-125)*w), g2=Math.round(246-(246-138)*w), bv=Math.round(252-(252-150)*w);
  return `rgb(${r},${g2},${bv})`;
}

function dCloud() {
  const cx=C.x, cy=C.y+C.droop, w=C.w;
  ctx.save(); ctx.translate(cx,cy);

  ctx.globalAlpha=0.07+w*0.16;
  ctx.fillStyle=`rgba(70,90,140,0.8)`;
  ctx.beginPath(); ctx.ellipse(4,11,28,10,0,0,Math.PI*2); ctx.fill();
  ctx.globalAlpha=1;

  const col=cloudColor(w);
  [{x:0,y:0,r:22+C.jig*0.3},{x:-18,y:7,r:16},{x:20,y:5,r:17.5},{x:-10,y:14,r:14.5},{x:12,y:14,r:14}]
    .forEach(p=>{ ctx.fillStyle=col; ctx.beginPath(); ctx.arc(p.x,p.y,p.r,0,Math.PI*2); ctx.fill(); });

  if (w > 0.04) {
    ctx.strokeStyle=`rgba(55,115,200,${w*0.68})`; ctx.lineWidth=3; ctx.lineCap='round';
    ctx.beginPath(); ctx.arc(0,8,20,0.2,0.2+w*Math.PI*1.55); ctx.stroke();
  }

  const dn=Math.max(1,Math.round(w*7));
  for (let i=0;i<dn;i++) {
    const dx=-14+i*(28/Math.max(dn-1,1)), dl=5+Math.sin(fr*0.11+i*1.4)*4.5+w*9;
    ctx.strokeStyle=`rgba(65,135,215,${0.38+w*0.44})`; ctx.lineWidth=1.7; ctx.lineCap='round';
    ctx.beginPath(); ctx.moveTo(dx,19); ctx.lineTo(dx+w*1.1,19+dl); ctx.stroke();
  }

  const ey=-3.5, eyeH=w>0.68?1.2:(w>0.42?2.5:4.2);
  ctx.fillStyle='#2d1b4e';
  ctx.beginPath(); ctx.ellipse(-8,ey,3,eyeH,0,0,Math.PI*2); ctx.fill();
  ctx.beginPath(); ctx.ellipse(8,ey,3,eyeH,0,0,Math.PI*2); ctx.fill();
  if (eyeH>2) {
    ctx.fillStyle='#fff';
    ctx.beginPath(); ctx.arc(-7,ey-1.3,1.2,0,Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.arc(9,ey-1.3,1.2,0,Math.PI*2); ctx.fill();
  }
  ctx.strokeStyle='#2d1b4e'; ctx.lineWidth=1.7; ctx.lineCap='round';
  if (C.eye==='scared') {
    ctx.beginPath(); ctx.moveTo(-12,ey-7); ctx.lineTo(-5,ey-4.5); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(12,ey-7); ctx.lineTo(5,ey-4.5); ctx.stroke();
  } else if (C.eye==='worried') {
    ctx.beginPath(); ctx.moveTo(-11,ey-5.5); ctx.lineTo(-5,ey-6.5); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(11,ey-5.5); ctx.lineTo(5,ey-6.5); ctx.stroke();
  }
  ctx.beginPath(); ctx.lineWidth=1.7;
  if (C.eye==='scared') ctx.arc(0,9,4.5,0.3,Math.PI-0.3,true);
  else if (C.eye==='worried') ctx.arc(0,8.5,4,0.25,Math.PI-0.25);
  else ctx.arc(0,7.5,4.5,0.05,Math.PI-0.05);
  ctx.stroke();
  ctx.restore();
}

function dParts() {
  parts.forEach(p => {
    ctx.globalAlpha = (p.life/p.max)*0.92;
    ctx.fillStyle=p.col;
    ctx.beginPath(); ctx.arc(p.x,p.y,p.r,0,Math.PI*2); ctx.fill();
  }); ctx.globalAlpha=1;
}

function dGround() {
  const gcols={City:'#2d1b4e',Forest:'#143310',Mountains:'#252535',Desert:'#7a5808'};
  ctx.fillStyle=gcols[WORLD_NAMES[worldIdx]]||'#2d1b4e';
  ctx.fillRect(0,H()-6,W(),6);
}

function dHUD() {
  document.getElementById('score').textContent=`${score}  ·  best ${hi}`;
  const ce=document.getElementById('combo');
  if (comboCount>=2) { ce.style.opacity='1'; ce.textContent=`× ${comboCount}  LIGHT STREAK`; }
  else ce.style.opacity='0';

  if (!tutDone && !C.dead) {
    ctx.save();
    ctx.globalAlpha=Math.min(1,(240-tutTimer)/55)*0.88;
    drawHint(C.x, C.y-60, 'HOLD SPACE  ↑  float up');
    if (tutTimer>55) {
      ctx.globalAlpha=Math.min(1,(tutTimer-55)/38)*Math.min(1,(240-tutTimer)/55)*0.82;
      drawHint(C.x, C.y+65, 'DOUBLE-TAP  ✦  shed rain');
    }
    ctx.restore();
  }
}

function drawHint(x,y,text) {
  ctx.font='700 11px -apple-system,sans-serif'; ctx.textAlign='center';
  const tw=ctx.measureText(text).width, pad=11, hh=27;
  ctx.fillStyle='rgba(15,6,40,0.65)';
  ctx.beginPath();
  if (ctx.roundRect) ctx.roundRect(x-tw/2-pad, y-hh/2, tw+pad*2, hh, 6);
  else ctx.rect(x-tw/2-pad, y-hh/2, tw+pad*2, hh);
  ctx.fill();
  ctx.fillStyle='rgba(255,255,255,0.95)';
  ctx.fillText(text, x, y+4);
  ctx.textAlign='left';
}

// ─── OVERLAYS ────────────────────────────────────────────
function showGameOver() {
  const msgs={fell:'Drifted too low…',building:'Crashed into a building!',overload:'Too heavy — you burst!',lightning:'Struck by lightning!'};
  document.getElementById('goReason').textContent=msgs[deathReason]||'Gone with the wind!';
  document.getElementById('goScore').textContent=score;
  const bestEl=document.getElementById('goBest');
  if (wasNewBest) { bestEl.className='newbest'; bestEl.textContent='🌟 New best score!'; }
  else { bestEl.className='best'; bestEl.textContent=`Best: ${hi}`; }
  const go=document.getElementById('gameover');
  go.style.display='flex';
  requestAnimationFrame(()=>requestAnimationFrame(()=>go.classList.add('show')));
}

// ─── INPUT ───────────────────────────────────────────────
function onDown(e) {
  if (!playing) return;
  if (!holdStarted) { holdStarted=true; sfxWhoosh(); }
  held=true;
  const now=Date.now();
  if (now-lastTap<280) { tapCount++; if(tapCount>=2){releaseRain();tapCount=0;} } else tapCount=1;
  lastTap=now;
}
function onUp() { held=false; holdStarted=false; ceilingLocked=false; }
function releaseRain() {
  if (C.w<0.06) return;
  C.w=Math.max(0,C.w-(0.28+C.w*0.12)); C.vy-=1.8; sfxSplash();
  for (let i=0;i<14;i++) spawnPart(C.x+(-18+Math.random()*36),C.y+20,'rgba(89,180,240,0.88)',(-2.5+Math.random()*5),(2+Math.random()*3));
}

document.addEventListener('keydown',e=>{ if(e.code==='Space'){e.preventDefault();onDown(e);} });
document.addEventListener('keyup',e=>{ if(e.code==='Space')onUp(); });
document.addEventListener('mousedown',e=>{ if(e.target.tagName==='BUTTON')return; onDown(e); });
document.addEventListener('mouseup',onUp);
document.addEventListener('touchstart',e=>{ if(e.target.tagName==='BUTTON')return; e.preventDefault(); onDown(e); },{passive:false});
document.addEventListener('touchend',e=>{ e.preventDefault(); onUp(); },{passive:false});

// ─── GAME FLOW ───────────────────────────────────────────
function startGame() {
  const go=document.getElementById('gameover');
  go.classList.remove('show');
  go.style.display='none';
  document.getElementById('menuscreen').style.display='none';
  document.getElementById('menuHi').textContent=hi>0?`Best: ${hi}`:'';
  initGame();
  playing=true;
  if(!muted) startAmb();
}
window.startGame=startGame;

// ─── MAIN LOOP ───────────────────────────────────────────
function loop() {
  if (playing) update();
  if (C.dead) {
    C.burstT++;
    if (C.burstT === 1) {
      sfxDeath();
      const isNew = score >= hi && score > 0;
      if (isNew && !wasNewBest) { wasNewBest=true; setTimeout(sfxChime,500); }
      for (let i=0;i<22;i++) {
        const col=['#fff','#c8dff5','#a0c8f0','#e0f0ff','#ffd580'][i%5];
        spawnPart(C.x+(-20+Math.random()*40), C.y+(-14+Math.random()*28), col, (-4+Math.random()*8), (-4+Math.random()*6));
      }
    }
    parts.forEach(p=>{ p.x+=p.vx; p.y+=p.vy; p.vy+=0.055; p.vx*=0.96; p.life--; });
    parts = parts.filter(p=>p.life>0);
    if (C.burstT > 70) showGameOver();
  }
  draw();
  requestAnimationFrame(loop);
}

document.getElementById('menuHi').textContent=hi>0?`Best: ${hi}`:'';
loop();
document.getElementById("playBtn").addEventListener("click", startGame);
document.getElementById("retryBtn").addEventListener("click", startGame);