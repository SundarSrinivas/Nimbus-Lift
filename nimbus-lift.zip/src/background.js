// Nimbus Lift — Background Service Worker
// Handles offline-triggered game launch with race-condition-safe locking
// that survives MV3 service worker restarts.

const GAME_PAGE = "game.html";
const GAME_URL = chrome.runtime.getURL(GAME_PAGE);
const GAME_URL_PREFIX = chrome.runtime.getURL(""); // e.g. chrome-extension://<id>/

// How long a "launch in progress" claim is considered valid.
// Protects against a SW crash mid-operation leaving a stale lock forever.
const LOCK_TTL_MS = 5000;

// After we've successfully ensured a game tab exists, ignore further
// WENT_OFFLINE events for this long. This absorbs connection flapping
// (offline -> online -> offline) without spawning new launch attempts.
const COOLDOWN_MS = 4000;

const LOCK_KEY = "nimbusLift_launchLock";
const COOLDOWN_KEY = "nimbusLift_lastLaunchAt";
const LAST_ONLINE_STATE_KEY = "nimbusLift_lastOnlineState";

// Service workers can be suspended/killed when idle, so setInterval is not
// reliable here. chrome.alarms persists across SW restarts and wakes the
// worker back up to run this check, which is why we use it instead of a
// plain JS timer. This makes offline detection independent of any single
// content script / tab being loaded, visible, or unthrottled.
const POLL_ALARM_NAME = "nimbusLift_connectivityPoll";
const POLL_INTERVAL_MINUTES = 0.25; // 15s; chrome.alarms minimum is ~30s in
                                     // practice when unpacked, can be lower
                                     // when run as a packed/published ext.

// ---------------------------------------------------------------------------
// In-memory promise chain. This is NOT the source of truth for correctness
// (the SW can be killed at any time), but as long as the SW process is alive
// it serializes overlapping messages so we never run two query->create
// sequences concurrently in the same worker instance. The storage-based
// lock below covers the cross-restart case.
// ---------------------------------------------------------------------------
let queue = Promise.resolve();

function enqueue(task) {
  // Chain onto the existing queue; always resolve so one failure doesn't
  // wedge all future events.
  const next = queue.then(task, task);
  queue = next.catch(() => {});
  return next;
}

// ---------------------------------------------------------------------------
// Storage-based lock helpers (chrome.storage.session survives SW restarts
// for the lifetime of the browser session, unlike a plain JS variable).
// ---------------------------------------------------------------------------

async function tryAcquireLock() {
  const now = Date.now();
  const data = await chrome.storage.session.get([LOCK_KEY, COOLDOWN_KEY]);

  // Respect cooldown from a recent successful launch (handles flapping).
  const lastLaunch = data[COOLDOWN_KEY] || 0;
  if (now - lastLaunch < COOLDOWN_MS) {
    return { acquired: false, reason: "cooldown" };
  }

  const existingLock = data[LOCK_KEY];
  if (existingLock && now - existingLock < LOCK_TTL_MS) {
    return { acquired: false, reason: "locked" };
  }

  // Claim the lock. This is a simple write, not a true atomic
  // compare-and-swap, but combined with the in-process queue (which
  // serializes calls within one SW lifetime) and the short TTL, the
  // realistic collision window is negligible. If you need a hard
  // guarantee across multiple simultaneously-running SW instances,
  // see the note at the bottom of this file.
  await chrome.storage.session.set({ [LOCK_KEY]: now });
  return { acquired: true };
}

async function releaseLock({ success }) {
  const updates = { [LOCK_KEY]: 0 };
  if (success) {
    updates[COOLDOWN_KEY] = Date.now();
  }
  await chrome.storage.session.set(updates);
}

// ---------------------------------------------------------------------------
// Tab helpers
// ---------------------------------------------------------------------------

function isGameTab(tab) {
  // startsWith handles any querystring/hash game.html might carry
  // (e.g. game.html#level=3), unlike strict equality.
  return !!tab.url && tab.url.startsWith(GAME_URL_PREFIX) &&
    tab.url.startsWith(chrome.runtime.getURL(GAME_PAGE));
}

async function findExistingGameTab() {
  const tabs = await chrome.tabs.query({});
  return tabs.find(isGameTab) || null;
}

async function focusTab(tab) {
  // Bring the tab itself to the front of its window...
  await chrome.tabs.update(tab.id, { active: true });
  // ...and bring that window to the foreground if it isn't already.
  const win = await chrome.windows.get(tab.windowId);
  if (!win.focused) {
    await chrome.windows.update(tab.windowId, { focused: true });
  }
}

async function isGameTabActiveAndFocused(tab) {
  if (!tab.active) return false;
  try {
    const win = await chrome.windows.get(tab.windowId);
    return !!win.focused;
  } catch {
    return false;
  }
}

// ---------------------------------------------------------------------------
// Core handler — the actual query -> decide -> act sequence, serialized
// through enqueue() so overlapping messages within one SW lifetime can't
// interleave their tabs.query / tabs.create calls.
// ---------------------------------------------------------------------------

async function handleWentOffline() {
  const lock = await tryAcquireLock();
  if (!lock.acquired) {
    // Either another launch is in flight, or we're in the post-launch
    // cooldown window (connection flapping). Either way, do nothing —
    // scenarios 4 and 5 are satisfied by simply not acting.
    return { ok: true, action: "skipped", reason: lock.reason };
  }

  try {
    const existing = await findExistingGameTab();

    if (existing) {
      // Scenario 3: if the game is already the active, focused tab,
      // leave it completely alone — no update calls, no risk of any
      // visible flicker or interruption to gameplay.
      const alreadyFront = await isGameTabActiveAndFocused(existing);
      if (!alreadyFront) {
        // Scenario 2 / 6: bring the existing tab to the foreground.
        await focusTab(existing);
      }
      return { ok: true, action: "focused", tabId: existing.id };
    }

    // Scenario 1: no game tab exists anywhere — open one.
    const created = await chrome.tabs.create({ url: GAME_URL });
    return { ok: true, action: "created", tabId: created.id };
  } finally {
    await releaseLock({ success: true });
  }
}

// ---------------------------------------------------------------------------
// Message listener
// ---------------------------------------------------------------------------

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || message.type !== "WENT_OFFLINE") {
    return false; // not for us
  }

  enqueue(handleWentOffline)
    .then((result) => sendResponse(result))
    .catch((err) => sendResponse({ ok: false, error: String(err) }));

  return true; // keep the message channel open for the async response
});

// ---------------------------------------------------------------------------
// Independent connectivity polling (service-worker side)
//
// Why this exists: a content script in a backgrounded/inactive tab can be
// throttled by Chrome, so its `offline` event listener may fire late or not
// at all. The service worker is not tied to any single tab's visibility, so
// polling navigator.onLine from here catches offline transitions that a
// backgrounded content script might miss or report late.
//
// navigator.onLine itself isn't perfectly reliable (it mainly reflects
// whether the OS reports a network interface as connected, not true
// internet reachability) but it's the same primitive content scripts use,
// so this acts as a redundant, tab-independent path to the same signal
// rather than a fundamentally different/better one.
// ---------------------------------------------------------------------------

async function checkConnectivityAndMaybeTrigger() {
  const isOnline = navigator.onLine;
  const data = await chrome.storage.session.get(LAST_ONLINE_STATE_KEY);
  const lastKnownOnline = data[LAST_ONLINE_STATE_KEY];

  // First run: just record state, don't treat "unknown -> X" as a transition.
  if (lastKnownOnline === undefined) {
    await chrome.storage.session.set({ [LAST_ONLINE_STATE_KEY]: isOnline });
    return;
  }

  if (lastKnownOnline === true && isOnline === false) {
    // Transitioned online -> offline since our last check.
    await chrome.storage.session.set({ [LAST_ONLINE_STATE_KEY]: false });
    enqueue(handleWentOffline).catch(() => {});
    return;
  }

  if (lastKnownOnline !== isOnline) {
    await chrome.storage.session.set({ [LAST_ONLINE_STATE_KEY]: isOnline });
  }
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === POLL_ALARM_NAME) {
    checkConnectivityAndMaybeTrigger().catch(() => {});
  }
});

function ensurePollingAlarm() {
  chrome.alarms.create(POLL_ALARM_NAME, {
    periodInMinutes: POLL_INTERVAL_MINUTES,
  });
}

// ---------------------------------------------------------------------------
// Misc
// ---------------------------------------------------------------------------

chrome.action.onClicked.addListener(async () => {
  const existing = await findExistingGameTab();
  if (existing) {
    await focusTab(existing);
  } else {
    await chrome.tabs.create({ url: GAME_URL });
  }
});

chrome.runtime.onInstalled.addListener(() => {
  console.log("Nimbus Lift installed!");
  // Clear any stale lock/cooldown from a previous session, just in case.
  chrome.storage.session.set({ [LOCK_KEY]: 0, [COOLDOWN_KEY]: 0 });
  ensurePollingAlarm();
});

chrome.runtime.onStartup.addListener(() => {
  ensurePollingAlarm();
});

// Also arm it immediately when this SW instance spins up (covers the case
// where the worker restarts mid-session and onStartup/onInstalled don't fire).
ensurePollingAlarm();

// If the game tab is closed, nothing special needs to happen here — the
// next WENT_OFFLINE event will simply find no existing tab and create one.
// This listener is included only if you want logging/telemetry; it's safe
// to remove.
chrome.tabs.onRemoved.addListener((tabId) => {
  // no-op placeholder — intentionally left for future use
});