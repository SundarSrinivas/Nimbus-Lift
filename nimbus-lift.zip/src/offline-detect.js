// Nimbus Lift — Offline Detector
// Injected into every page. Notifies background when connection drops.

(function () {
  let wasOnline = navigator.onLine;

  window.addEventListener('offline', () => {
    if (wasOnline) {
      wasOnline = false;
      // Small delay to avoid triggering on brief blips
      setTimeout(() => {
        if (!navigator.onLine) {
          chrome.runtime.sendMessage({ type: 'WENT_OFFLINE' });
        }
      }, 800);
    }
  });

  window.addEventListener('online', () => {
    wasOnline = true;
  });
})();
